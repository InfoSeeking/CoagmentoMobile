//
//  WebpageItem.m
//  CoagmentoIOS
//
//  Created by Josue Reyes on 8/21/13.
//  Copyright (c) 2013 Josue Reyes. All rights reserved.
//

#import "WebpageItem.h"

@implementation WebpageItem

@end
