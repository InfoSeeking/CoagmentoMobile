//
//  SOTextField.h
//  CoagmentoIOS
//
//  Created by Josue Reyes on 7/17/13.
//  Copyright (c) 2013 Josue Reyes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SOTextField : UITextField

@property (nonatomic, readwrite, assign) IBOutlet UITextField *nextField;


@end
