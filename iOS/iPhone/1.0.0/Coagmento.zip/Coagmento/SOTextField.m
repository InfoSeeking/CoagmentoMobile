//
//  SOTextField.m
//  CoagmentoIOS
//
//  Created by Josue Reyes on 7/17/13.
//  Copyright (c) 2013 Josue Reyes. All rights reserved.
//

#import "SOTextField.h"

@implementation SOTextField

@synthesize nextField;


@end
