//
//  CSpace.h
//  CoagmentoIOS
//
//  Created by Josue Reyes on 7/23/13.
//  Copyright (c) 2013 Josue Reyes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSpace : UICollectionView

@property (nonatomic, strong) NSString *Key;


@end
