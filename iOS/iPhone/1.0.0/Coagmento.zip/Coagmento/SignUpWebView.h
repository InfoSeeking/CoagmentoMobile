//
//  SignUpWebView.h
//  CoagmentoIOS
//
//  Created by Josue Reyes on 10/15/13.
//  Copyright (c) 2013 Josue Reyes. All rights reserved.
//

#import "WebViewController.h"

@interface SignUpWebView : WebViewController <UIWebViewDelegate>{

}



@property (strong, retain) IBOutlet UIWebView *webView;

@end
