# Tweet Stream

This is an example of how to use json-framework to interact with [Twitter's streaming API](http://dev.twitter.com/pages/streaming_api). It uses the streaming capabilities of the parser to display an "endless" stream of tweets, despite performing only a single HTTP request.

Additionally, this shows how you can use external linking to link to a checkout of json-framework in the same workspace, rather than copying the sources into your project.
